
export const backendURL = import.meta.env.VITE_BACKEND_URL || 'http://localhost:8000';
